package com.example.baran.mobileprogrammingproject;

import android.support.annotation.NonNull;
import android.support.design.internal.NavigationMenu;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle actionBar;
    private NavigationView navigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawerLayout=findViewById(R.id.drawer);
        navigationView=findViewById(R.id.left_navigation);
        actionBar=new ActionBarDrawerToggle(this,drawerLayout,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(actionBar);
        actionBar.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit();
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
               Fragment selectFragment=null;
               switch (menuItem.getItemId())
               {
                   case R.id.nav_home:
                       selectFragment=new HomeFragment();
                       break;
                   case R.id.nav_restaurant:
                       selectFragment=new RestaurantFragment();
                       break;

               }
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,selectFragment).commit();
                drawerLayout.closeDrawers();
                return  true;
            }
        });
    }
    @Override

    public boolean onOptionsItemSelected(MenuItem menuItem)
    {
        Fragment selectFragment=null;
        if (actionBar.onOptionsItemSelected(menuItem)) {

            return true;
        }

        return  super.onOptionsItemSelected(menuItem);
    }



}
